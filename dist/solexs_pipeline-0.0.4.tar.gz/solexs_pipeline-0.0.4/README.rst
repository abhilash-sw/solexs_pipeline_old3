===============
solexs_pipeline
===============


.. image:: https://img.shields.io/pypi/v/solexs_pipeline.svg
        :target: https://pypi.python.org/pypi/solexs_pipeline

.. image:: https://img.shields.io/travis/leme-cosmo/solexs_pipeline.svg
        :target: https://travis-ci.org/leme-cosmo/solexs_pipeline

.. image:: https://readthedocs.org/projects/solexs-pipeline/badge/?version=latest
        :target: https://solexs-pipeline.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Data Pipeline for SoLEXS on-board Aditya-L1


* Free software: MIT license
* Documentation: https://solexs-pipeline.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
