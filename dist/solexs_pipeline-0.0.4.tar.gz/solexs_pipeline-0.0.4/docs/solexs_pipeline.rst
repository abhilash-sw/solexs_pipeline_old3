solexs\_pipeline package
========================

Submodules
----------

solexs\_pipeline.binary\_read module
------------------------------------

.. automodule:: solexs_pipeline.binary_read
    :members:
    :undoc-members:
    :show-inheritance:

solexs\_pipeline.calibration\_spectrum\_fitting module
------------------------------------------------------

.. automodule:: solexs_pipeline.calibration_spectrum_fitting
    :members:
    :undoc-members:
    :show-inheritance:

solexs\_pipeline.cli module
---------------------------

.. automodule:: solexs_pipeline.cli
    :members:
    :undoc-members:
    :show-inheritance:

solexs\_pipeline.solexs\_pipeline module
----------------------------------------

.. automodule:: solexs_pipeline.solexs_pipeline
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: solexs_pipeline
    :members:
    :undoc-members:
    :show-inheritance:
